/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        brown: {
          600: '#8B4513',
          700: '#693610',
        },
      },
    },
  },
  plugins: [],
}