export interface FilterOptions {
  amenities: {
    wifi: boolean;
    veganOptions: boolean;
    hasPastries: boolean;
    outdoorSeating: boolean;
    hasFood: boolean;
  };
  size: string | null;
}

export const defaultFilters: FilterOptions = {
  amenities: {
    wifi: false,
    veganOptions: false,
    hasPastries: false,
    outdoorSeating: false,
    hasFood: false,
  },
  size: null,
};

export const filterShops = (shops: any[], filters: FilterOptions) => {
  return shops.filter(shop => {
    // Amenities filter
    const amenitiesMatch = Object.entries(filters.amenities).every(([key, value]) => {
      if (!value) return true; // Skip if filter is not active
      return shop.amenities?.[key] === true;
    });

    // Size filter
    const sizeMatch = !filters.size || shop.amenities?.size === filters.size;

    return amenitiesMatch && sizeMatch;
  });
};