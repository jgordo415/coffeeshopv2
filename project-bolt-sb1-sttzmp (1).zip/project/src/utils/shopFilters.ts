import type { CoffeeShop } from '../types/coffee';
import type { FilterOptions } from './filters';
import { getNeighborhoodFromAddress } from './filters';

export const filterShops = (shops: CoffeeShop[], filters: FilterOptions): CoffeeShop[] => {
  return shops.filter(shop => {
    // Neighborhood filter
    const shopNeighborhood = getNeighborhoodFromAddress(shop.address);
    const neighborhoodMatch = 
      filters.neighborhoods.length === 0 || 
      filters.neighborhoods.includes(shopNeighborhood);

    // Price filter
    const priceMatch = 
      filters.prices.length === 0 || 
      filters.prices.includes(shop.priceRange);

    // Amenities filter
    const amenitiesMatch = Object.entries(filters.amenities).every(([key, value]) => {
      if (!value) return true; // Skip if filter is not active
      return shop.amenities?.[key as keyof typeof shop.amenities] === true;
    });

    // Size filter
    const sizeMatch = 
      !filters.size || 
      shop.amenities?.capacity === filters.size;

    return neighborhoodMatch && priceMatch && amenitiesMatch && sizeMatch;
  });
};