import { useState, useEffect } from 'react';
import type { FilterOptions } from '../utils/filters';
import { neighborhoods, priceRanges, defaultFilters } from '../utils/filters';

export default function Filters() {
  const [filters, setFilters] = useState<FilterOptions>(defaultFilters);
  const [showAmenities, setShowAmenities] = useState(false);

  const dispatchFilterChange = (newFilters: FilterOptions) => {
    const event = new CustomEvent('filterChange', {
      detail: newFilters,
      bubbles: true,
      composed: true
    });
    document.dispatchEvent(event);
  };

  const handleFilterChange = (newFilters: FilterOptions) => {
    setFilters(newFilters);
    dispatchFilterChange(newFilters);
  };

  const handleNeighborhoodChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    handleFilterChange({
      ...filters,
      neighborhoods: value ? [value] : []
    });
  };

  const handlePriceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    handleFilterChange({
      ...filters,
      prices: value ? [value] : []
    });
  };

  const handleAmenityChange = (amenity: keyof FilterOptions['amenities']) => {
    handleFilterChange({
      ...filters,
      amenities: {
        ...filters.amenities,
        [amenity]: !filters.amenities[amenity]
      }
    });
  };

  const getActiveAmenitiesCount = () => {
    return Object.values(filters.amenities).filter(Boolean).length;
  };

  return (
    <div className="mb-8 bg-white p-4 rounded-lg shadow-sm">
      <div className="flex flex-wrap gap-4">
        {/* Neighborhood Dropdown */}
        <div className="flex-1 min-w-[200px]">
          <select
            value={filters.neighborhoods[0] || ''}
            onChange={handleNeighborhoodChange}
            className="w-full px-3 py-2 border rounded-lg text-gray-700 focus:outline-none focus:ring-2 focus:ring-brown-600"
          >
            <option value="">All Neighborhoods</option>
            {neighborhoods.map(neighborhood => (
              <option key={neighborhood} value={neighborhood}>
                {neighborhood}
              </option>
            ))}
          </select>
        </div>

        {/* Price Range Dropdown */}
        <div className="flex-1 min-w-[150px]">
          <select
            value={filters.prices[0] || ''}
            onChange={handlePriceChange}
            className="w-full px-3 py-2 border rounded-lg text-gray-700 focus:outline-none focus:ring-2 focus:ring-brown-600"
          >
            <option value="">Any Price</option>
            {priceRanges.map(price => (
              <option key={price} value={price}>
                {price}
              </option>
            ))}
          </select>
        </div>

        {/* Amenities Dropdown */}
        <div className="relative flex-1 min-w-[200px]">
          <button
            onClick={() => setShowAmenities(!showAmenities)}
            className="w-full px-3 py-2 border rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-brown-600 flex justify-between items-center"
          >
            <span>
              {getActiveAmenitiesCount() === 0
                ? 'Amenities'
                : `${getActiveAmenitiesCount()} selected`}
            </span>
            <svg
              className={`w-5 h-5 transition-transform ${showAmenities ? 'rotate-180' : ''}`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 9l-7 7-7-7"
              />
            </svg>
          </button>

          {showAmenities && (
            <div className="absolute z-10 w-full mt-1 bg-white border rounded-lg shadow-lg">
              <div className="p-2">
                {Object.entries(filters.amenities).map(([key, value]) => (
                  <button
                    key={key}
                    onClick={() => handleAmenityChange(key as keyof FilterOptions['amenities'])}
                    className="w-full px-3 py-2 text-left hover:bg-gray-100 rounded flex items-center gap-2"
                  >
                    <div className={`w-4 h-4 border rounded ${value ? 'bg-brown-600 border-brown-600' : 'border-gray-300'}`}>
                      {value && (
                        <svg className="w-4 h-4 text-white" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                    {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}