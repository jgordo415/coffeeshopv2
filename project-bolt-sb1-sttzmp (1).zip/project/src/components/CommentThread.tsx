import { useState } from 'react';
import type { Comment } from '../types/community';

interface Props {
  comment: Comment;
  onVote: (commentId: string, value: number) => void;
}

export default function CommentThread({ comment, onVote }: Props) {
  const [userVote, setUserVote] = useState<number>(0);

  const handleVote = (value: number) => {
    if (userVote === value) {
      onVote(comment.id, -value);
      setUserVote(0);
    } else {
      onVote(comment.id, value - userVote);
      setUserVote(value);
    }
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="flex gap-4">
      <div className="flex flex-col items-center gap-1">
        <button
          onClick={() => handleVote(1)}
          className={`p-1 rounded hover:bg-gray-100 ${
            userVote === 1 ? 'text-orange-500' : 'text-gray-400'
          }`}
        >
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 0l-3 3a1 1 0 001.414 1.414L9 9.414V13a1 1 0 102 0V9.414l1.293 1.293a1 1 0 001.414-1.414z" clipRule="evenodd" />
          </svg>
        </button>
        <span className={`text-sm font-medium ${
          comment.votes > 0 ? 'text-orange-500' :
          comment.votes < 0 ? 'text-blue-500' :
          'text-gray-500'
        }`}>
          {comment.votes}
        </span>
        <button
          onClick={() => handleVote(-1)}
          className={`p-1 rounded hover:bg-gray-100 ${
            userVote === -1 ? 'text-blue-500' : 'text-gray-400'
          }`}
        >
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 2a8 8 0 100 16 8 8 0 000-16zm3.707 8.707l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 011.414-1.414L9 10.586V7a1 1 0 112 0v3.586l1.293-1.293a1 1 0 011.414 1.414z" clipRule="evenodd" />
          </svg>
        </button>
      </div>

      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span className="font-medium">{comment.username}</span>
          <span className="text-sm text-gray-500">•</span>
          <span className="text-sm text-gray-500">{formatDate(comment.timestamp)}</span>
        </div>
        <p className="text-gray-700">{comment.content}</p>
        
        {comment.replies.length > 0 && (
          <div className="mt-4 ml-4 space-y-4 border-l-2 border-gray-100 pl-4">
            {comment.replies.map(reply => (
              <CommentThread
                key={reply.id}
                comment={reply}
                onVote={onVote}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}