import { useFilters } from './FilterContext';
import AmenitiesFilter from './AmenitiesFilter';
import SizeFilter from './SizeFilter';

export default function FilterBar() {
  const { filters, updateFilters } = useFilters();

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <AmenitiesFilter
          amenities={filters.amenities}
          onChange={(amenities) => updateFilters({ amenities })}
        />
        <SizeFilter
          size={filters.size}
          onChange={(size) => updateFilters({ size })}
        />
      </div>
    </div>
  );
}