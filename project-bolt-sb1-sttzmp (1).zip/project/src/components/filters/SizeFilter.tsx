interface Props {
  size: string | null;
  onChange: (size: string | null) => void;
}

export default function SizeFilter({ size, onChange }: Props) {
  return (
    <div>
      <h3 className="font-medium mb-2">Size</h3>
      <select
        value={size || ''}
        onChange={(e) => onChange(e.target.value || null)}
        className="w-full p-2 border rounded"
      >
        <option value="">Any size</option>
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="Large">Large</option>
      </select>
    </div>
  );
}