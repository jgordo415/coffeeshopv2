interface Props {
  amenities: {
    wifi: boolean;
    veganOptions: boolean;
    hasPastries: boolean;
    outdoorSeating: boolean;
    hasFood: boolean;
  };
  onChange: (amenities: Props['amenities']) => void;
}

export default function AmenitiesFilter({ amenities, onChange }: Props) {
  return (
    <div className="space-y-2">
      <h3 className="font-medium">Amenities</h3>
      <div className="space-y-1">
        {Object.entries(amenities).map(([key, value]) => (
          <label key={key} className="flex items-center">
            <input
              type="checkbox"
              checked={value}
              onChange={(e) => onChange({
                ...amenities,
                [key]: e.target.checked
              })}
              className="mr-2"
            />
            {key.replace(/([A-Z])/g, ' $1').trim()}
          </label>
        ))}
      </div>
    </div>
  );
}