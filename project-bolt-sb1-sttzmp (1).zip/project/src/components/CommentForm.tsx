import { useState } from 'react';

interface Props {
  onSubmit: (content: string) => void;
}

export default function CommentForm({ onSubmit }: Props) {
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (content.trim()) {
      onSubmit(content.trim());
      setContent('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Share your experience..."
        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-brown-500 focus:border-brown-500"
        rows={4}
      />
      <button
        type="submit"
        disabled={!content.trim()}
        className="px-4 py-2 bg-brown-600 text-white rounded-lg hover:bg-brown-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Post Comment
      </button>
    </form>
  );
}