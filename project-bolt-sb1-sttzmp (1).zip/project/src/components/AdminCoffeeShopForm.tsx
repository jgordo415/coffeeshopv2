import { useState } from 'react';
import type { CoffeeShop, CoffeeBean, MenuHighlight, Ambience } from '../types/coffee';

interface Props {
  onSubmit: (shop: Partial<CoffeeShop>) => void;
  initialData?: Partial<CoffeeShop>;
}

export default function AdminCoffeeShopForm({ onSubmit, initialData = {} }: Props) {
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    description: '',
    specialty: '',
    priceRange: '$',
    googleMapsUrl: '',
    imageUrl: '',
    tags: [] as string[],
    neighborhood: '',
    ...initialData
  });

  const [newTag, setNewTag] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleTagAdd = () => {
    if (newTag && !formData.tags.includes(newTag)) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag]
      }));
      setNewTag('');
    }
  };

  const handleTagRemove = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700">Name</label>
        <input
          type="text"
          value={formData.name}
          onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Address</label>
        <input
          type="text"
          value={formData.address}
          onChange={e => setFormData(prev => ({ ...prev, address: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Neighborhood</label>
        <input
          type="text"
          value={formData.neighborhood}
          onChange={e => setFormData(prev => ({ ...prev, neighborhood: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
          required
          placeholder="Enter neighborhood name"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Description</label>
        <textarea
          value={formData.description}
          onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
          rows={3}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Specialty</label>
        <input
          type="text"
          value={formData.specialty}
          onChange={e => setFormData(prev => ({ ...prev, specialty: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Price Range</label>
        <select
          value={formData.priceRange}
          onChange={e => setFormData(prev => ({ ...prev, priceRange: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
          required
        >
          <option value="$">$</option>
          <option value="$$">$$</option>
          <option value="$$$">$$$</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Google Maps URL</label>
        <input
          type="url"
          value={formData.googleMapsUrl}
          onChange={e => setFormData(prev => ({ ...prev, googleMapsUrl: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Image URL</label>
        <input
          type="url"
          value={formData.imageUrl}
          onChange={e => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Tags</label>
        <div className="flex gap-2 mb-2">
          <input
            type="text"
            value={newTag}
            onChange={e => setNewTag(e.target.value)}
            className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-brown-500 focus:ring-brown-500"
            placeholder="Enter a tag"
          />
          <button
            type="button"
            onClick={handleTagAdd}
            className="px-4 py-2 bg-brown-600 text-white rounded-md hover:bg-brown-700"
          >
            Add Tag
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {formData.tags.map(tag => (
            <span
              key={tag}
              className="inline-flex items-center px-2 py-1 rounded-full text-sm bg-gray-100"
            >
              {tag}
              <button
                type="button"
                onClick={() => handleTagRemove(tag)}
                className="ml-1 text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </span>
          ))}
        </div>
      </div>

      <button
        type="submit"
        className="w-full px-4 py-2 bg-brown-600 text-white rounded-md hover:bg-brown-700"
      >
        Save Coffee Shop
      </button>
    </form>
  );
}