import { useEffect, useState } from 'react';
import type { CoffeeShop } from '@/types/coffee';
import { useFilters } from './filters/FilterContext';
import { filterShops } from '@/utils/filters';
import CoffeeShopCard from './CoffeeShopCard.astro';

interface Props {
  shops: CoffeeShop[];
}

export default function CoffeeShopList({ shops }: Props) {
  const { filters } = useFilters();
  const [filteredShops, setFilteredShops] = useState(shops);

  useEffect(() => {
    setFilteredShops(filterShops(shops, filters));
  }, [shops, filters]);

  if (filteredShops.length === 0) {
    return (
      <div className="text-center py-12">
        <h3 className="text-xl font-semibold text-gray-700">No coffee shops found</h3>
        <p className="text-gray-500 mt-2">Try adjusting your filters</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {filteredShops.map(shop => (
        <CoffeeShopCard key={shop.id} shop={shop} />
      ))}
    </div>
  );
}