import { useState } from 'react';
import type { CommunityInsight, Comment, SortOption } from '../types/community';
import CommentThread from './CommentThread';
import CommentForm from './CommentForm';

interface Props {
  shopId: number;
  initialInsights: CommunityInsight;
}

export default function CommunityInsights({ shopId, initialInsights }: Props) {
  const [insights, setInsights] = useState(initialInsights);
  const [sortBy, setSortBy] = useState<SortOption>('top');

  const handleNewComment = (content: string) => {
    const newComment: Comment = {
      id: Date.now().toString(),
      userId: 'temp-user-id', // In real app, get from auth
      username: 'Anonymous', // In real app, get from auth
      content,
      timestamp: new Date().toISOString(),
      votes: 0,
      replies: []
    };

    setInsights(prev => ({
      ...prev,
      comments: [newComment, ...prev.comments],
      totalComments: prev.totalComments + 1
    }));
  };

  const handleVote = (commentId: string, value: number) => {
    setInsights(prev => ({
      ...prev,
      comments: prev.comments.map(comment => 
        comment.id === commentId
          ? { ...comment, votes: comment.votes + value }
          : comment
      )
    }));
  };

  const sortComments = (comments: Comment[]): Comment[] => {
    switch (sortBy) {
      case 'new':
        return [...comments].sort((a, b) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
      case 'top':
        return [...comments].sort((a, b) => b.votes - a.votes);
      case 'controversial':
        return [...comments].sort((a, b) => Math.abs(b.votes) - Math.abs(a.votes));
      default:
        return comments;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2">Community Insights</h2>
        <div className="flex items-center justify-between">
          <p className="text-gray-600">
            {insights.totalComments} comments • {insights.userRecommendations} recommendations
          </p>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="border rounded-md px-2 py-1 text-sm"
            >
              <option value="top">Top</option>
              <option value="new">New</option>
              <option value="controversial">Controversial</option>
            </select>
          </div>
        </div>
      </div>

      <CommentForm onSubmit={handleNewComment} />

      <div className="mt-8 space-y-6">
        {sortComments(insights.comments).map(comment => (
          <CommentThread
            key={comment.id}
            comment={comment}
            onVote={handleVote}
          />
        ))}
      </div>
    </div>
  );
}