import type { Rating } from '../types/coffee';

interface Props {
  ratings: Rating[];
}

export default function RatingsSummary({ ratings }: Props) {
  const calculateAverage = (key: keyof Rating) => {
    if (!ratings.length) return 0;
    const sum = ratings.reduce((acc, curr) => acc + curr[key], 0);
    return Math.round(sum / ratings.length);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-xl font-bold mb-4">Ratings Summary</h3>
      
      <div className="space-y-4">
        {Object.keys(ratings[0] || {}).map((key) => (
          <div key={key} className="flex items-center gap-4">
            <span className="w-24 text-sm capitalize">{key}</span>
            <div className="flex-1 h-2 bg-gray-200 rounded-full">
              <div
                className="h-full bg-brown-600 rounded-full"
                style={{ width: `${(calculateAverage(key as keyof Rating) / 5) * 100}%` }}
              />
            </div>
            <span className="text-sm font-medium">
              {calculateAverage(key as keyof Rating)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}