import { useState } from 'react';
import type { Rating } from '../types/coffee';

interface Props {
  onRatingSubmit: (rating: Rating, comment?: string) => void;
}

export default function RatingInput({ onRatingSubmit }: Props) {
  const [rating, setRating] = useState<Rating>({
    overall: 0,
    atmosphere: 0,
    quality: 0,
    uniqueness: 0
  });
  const [comment, setComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRatingSubmit(rating, comment);
    setRating({
      overall: 0,
      atmosphere: 0,
      quality: 0,
      uniqueness: 0
    });
    setComment('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-xl font-bold mb-4">Rate this Coffee Shop</h3>
      
      <div className="space-y-4 mb-6">
        {Object.entries(rating).map(([key, value]) => (
          <div key={key} className="flex items-center gap-4">
            <span className="w-24 text-sm capitalize">{key}</span>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map(num => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setRating(prev => ({ ...prev, [key]: num }))}
                  className={`w-8 h-8 rounded-full ${
                    num <= value ? 'bg-brown-600 text-white' : 'bg-gray-100'
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Comments (optional)
        </label>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="w-full px-3 py-2 border rounded-md"
          rows={3}
          placeholder="Share your experience..."
        />
      </div>

      <button
        type="submit"
        className="w-full bg-brown-600 text-white px-4 py-2 rounded-md hover:bg-brown-700 transition-colors"
        disabled={!rating.overall}
      >
        Submit Rating
      </button>
    </form>
  );
}