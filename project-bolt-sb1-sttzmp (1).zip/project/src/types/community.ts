export interface Comment {
  id: string;
  userId: string;
  username: string;
  content: string;
  timestamp: string;
  votes: number;
  replies: Comment[];
}

export interface CommunityInsight {
  id: string;
  shopId: number;
  comments: Comment[];
  totalComments: number;
  topTags: string[];
  userRecommendations: number;
}

export type SortOption = 'new' | 'top' | 'controversial';