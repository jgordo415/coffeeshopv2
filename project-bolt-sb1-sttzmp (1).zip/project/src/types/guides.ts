export interface LandmarkGuide {
  id: string;
  name: string;
  description: string;
  coffeeShops: {
    id: number;
    distance: string;
    walkingTime: string;
    highlights: string[];
  }[];
  imageUrl: string;
}

export interface LocalFavorite {
  id: number;
  shopId: number;
  localTips: string[];
  bestTimes: string[];
  insiderSecrets: string[];
  regularPerks: string[];
}

export interface HiddenGem {
  id: number;
  shopId: number;
  whyHidden: string;
  bestTimeToVisit: string;
  uniqueFeatures: string[];
  localStories: string[];
}