export interface CoffeeShop {
  id: number;
  name: string;
  address: string;
  description: string;
  specialty: string;
  priceRange: string;
  googleMapsUrl: string;
  tags: string[];
  amenities: {
    wifi: boolean;
    powerOutlets: boolean;
    veganOptions: boolean;
    hasPastries: boolean;
    hasFood: boolean;
    outdoorSeating: boolean;
    size: 'Small' | 'Medium' | 'Large';
  };
}

export interface Rating {
  overall: number;
  atmosphere: number;
  quality: number;
  uniqueness: number;
}