export interface EventSpeaker {
  name: string;
  role: string;
  company: string;
  bio: string;
  imageUrl: string;
}

export interface CoffeeEvent {
  id: number;
  title: string;
  description: string;
  date: string;
  time: string;
  location: {
    name: string;
    address: string;
    shopId?: number;
  };
  type: 'workshop' | 'tasting' | 'competition' | 'meetup' | 'class';
  price: number | 'free';
  capacity: number;
  registrationUrl: string;
  imageUrl: string;
  speakers?: EventSpeaker[];
  tags: string[];
  requirements?: string[];
  included?: string[];
}