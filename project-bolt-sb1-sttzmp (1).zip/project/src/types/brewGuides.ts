export interface BrewGuide {
  id: number;
  method: string;
  difficulty: string;
  timeRequired: string;
  steps: string[];
  equipment: string[];
  tips: string[];
  ratio?: {
    coffee: string;
    water: string;
  };
  grindSize: string;
  waterTemp: string;
  yield: string;
}

export interface DrinkComparison {
  name: string;
  description: string;
  ratio: {
    espresso: string;
    milk: string;
    foam: string;
  };
  size: string;
  characteristics: string[];
  imageUrl: string;
}