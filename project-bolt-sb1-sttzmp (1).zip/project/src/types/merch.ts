export interface MerchItem {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: 'apparel' | 'books' | 'equipment' | 'digital';
  available: boolean;
  preOrder?: boolean;
  releaseDate?: string;
  variants?: {
    type: string;
    options: string[];
  }[];
}

export interface DigitalProduct {
  id: number;
  title: string;
  description: string;
  price: number;
  coverImageUrl: string;
  format: string[];
  pages?: number;
  duration?: string;
  preview?: string;
  includes: string[];
}