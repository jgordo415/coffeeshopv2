import type { CoffeeShop } from '../types/coffee';

export const coffeeShops: CoffeeShop[] = [
  {
    id: 1,
    name: "Ritual Coffee Roasters",
    address: "1026 Valencia St, San Francisco, CA 94110",
    description: "Pioneering third-wave coffee shop known for direct-trade beans and expert baristas.",
    specialty: "Single-origin pour-overs",
    priceRange: "$$",
    googleMapsUrl: "https://maps.google.com/maps?q=ritual+coffee+valencia",
    tags: ["Third Wave", "Pour Over", "Single Origin"],
    amenities: {
      wifi: true,
      powerOutlets: true,
      veganOptions: true,
      hasPastries: true,
      hasFood: false,
      outdoorSeating: true,
      size: "Medium"
    }
  },
  {
    id: 2,
    name: "Sightglass Coffee",
    address: "270 7th St, San Francisco, CA 94103",
    description: "Industrial-chic cafe with house-roasted beans and brewing equipment shop.",
    specialty: "Cold brew",
    priceRange: "$$",
    googleMapsUrl: "https://maps.google.com/maps?q=sightglass+coffee+sf",
    tags: ["Roastery", "Cold Brew", "Equipment Shop"],
    amenities: {
      wifi: true,
      powerOutlets: true,
      veganOptions: true,
      hasPastries: true,
      hasFood: true,
      outdoorSeating: false,
      size: "Large"
    }
  }
];