import type { LocalFavorite } from '../types/guides';

export const localFavorites: LocalFavorite[] = [
  {
    id: 1,
    shopId: 1, // Ritual Coffee
    localTips: [
      'Ask for the secret menu "Valencia Sunrise" drink',
      'Best pastries arrive at 8am',
      'The window seats are perfect for people watching'
    ],
    bestTimes: [
      'Weekdays 2-4pm for quiet work sessions',
      'Saturday mornings for fresh pastries',
      'Sunday afternoons for live music'
    ],
    insiderSecrets: [
      'The baristas offer free tasting notes workshops on First Fridays',
      'Bring your own mug for a secret discount',
      'Ask about their coffee subscription beta program'
    ],
    regularPerks: [
      'Free coffee on your 10th visit',
      'Early access to seasonal drinks',
      'Invitation to cupping sessions'
    ]
  },
  {
    id: 2,
    shopId: 6, // Saint Frank
    localTips: [
      'Their pour-over coffee changes weekly',
      'The back corner has the best natural light',
      'Try the house-made almond milk'
    ],
    bestTimes: [
      'Early mornings for fresh roasts',
      'Tuesday afternoons are quietest',
      'Friday evenings for coffee cocktails'
    ],
    insiderSecrets: [
      'They sell their signature ceramics quarterly',
      'Ask about their coffee education programs',
      'Hidden menu includes seasonal specialties'
    ],
    regularPerks: [
      'Loyalty program includes free coffee workshops',
      'Birthday month discounts',
      'First access to limited roasts'
    ]
  }
];