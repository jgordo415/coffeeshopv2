import type { MerchItem, DigitalProduct } from '../types/merch';

export const merchItems: MerchItem[] = [
  {
    id: 1,
    name: "SF Coffee Guide 2025 - Official Book",
    description: "A comprehensive guide to San Francisco's best coffee shops, featuring detailed reviews, maps, and insider tips.",
    price: 29.99,
    imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=800",
    category: "books",
    available: true,
    variants: [
      {
        type: "format",
        options: ["Hardcover", "Paperback"]
      }
    ]
  },
  {
    id: 2,
    name: "Barista's Journal",
    description: "Premium coffee tasting notebook with guided entry pages and brewing ratio charts.",
    price: 24.99,
    imageUrl: "https://images.unsplash.com/photo-1517971071642-34a2d3ecc9cd?w=800",
    category: "books",
    available: true
  },
  {
    id: 3,
    name: "Coffee Lover's Tote",
    description: "100% organic cotton tote bag featuring our signature coffee shop map design.",
    price: 19.99,
    imageUrl: "https://images.unsplash.com/photo-1614179689702-355944cd0918?w=800",
    category: "apparel",
    available: true,
    variants: [
      {
        type: "color",
        options: ["Natural", "Black", "Navy"]
      }
    ]
  },
  {
    id: 4,
    name: "Limited Edition SF Coffee Tour T-Shirt",
    description: "Featuring all 20 neighborhoods and their signature coffee spots.",
    price: 34.99,
    imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800",
    category: "apparel",
    available: true,
    preOrder: true,
    releaseDate: "2025-03-01",
    variants: [
      {
        type: "size",
        options: ["S", "M", "L", "XL", "XXL"]
      },
      {
        type: "color",
        options: ["White", "Light Gray", "Dark Gray"]
      }
    ]
  }
];

export const digitalProducts: DigitalProduct[] = [
  {
    id: 1,
    title: "SF Coffee Guide 2025 - Digital Edition",
    description: "The complete digital version of our coffee guide, with interactive maps and regular updates throughout the year.",
    price: 14.99,
    coverImageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=800",
    format: ["PDF", "ePub", "Mobi"],
    pages: 250,
    preview: "https://example.com/preview/coffee-guide",
    includes: [
      "Interactive neighborhood maps",
      "Quarterly updates",
      "Exclusive digital content",
      "Mobile-optimized format"
    ]
  },
  {
    id: 2,
    title: "Home Barista Masterclass",
    description: "A comprehensive video course teaching you how to make cafe-quality coffee at home.",
    price: 79.99,
    coverImageUrl: "https://images.unsplash.com/photo-1461988320302-91bde64fc8e4?w=800",
    format: ["Video", "PDF Workbook"],
    duration: "4 hours",
    includes: [
      "12 video lessons",
      "Downloadable workbook",
      "Recipe cards",
      "Equipment guide",
      "Lifetime access"
    ]
  }
];