import type { CoffeeEvent } from '../types/events';

export const events: CoffeeEvent[] = [
  {
    id: 1,
    title: "Latte Art Masterclass",
    description: "Learn the secrets of creating stunning latte art from award-winning baristas. Perfect for both beginners and intermediate baristas looking to improve their skills.",
    date: "2025-02-15",
    time: "14:00-17:00",
    location: {
      name: "Coffee Movement",
      address: "1030 Washington St, San Francisco, CA 94108",
      shopId: 9
    },
    type: "class",
    price: 85,
    capacity: 12,
    registrationUrl: "https://example.com/events/latte-art-2025",
    imageUrl: "https://images.unsplash.com/photo-1534778356534-d3d45b6df1da?w=800",
    speakers: [
      {
        name: "Maria Chen",
        role: "Head Barista",
        company: "Coffee Movement",
        bio: "3-time Bay Area Latte Art Champion",
        imageUrl: "https://images.unsplash.com/photo-1573496799652-408c2ac9fe98?w=400"
      }
    ],
    tags: ["hands-on", "beginner-friendly", "certification"],
    requirements: [
      "No experience necessary",
      "All materials provided",
      "Bring an apron"
    ],
    included: [
      "3 hours of instruction",
      "Practice materials",
      "Take-home guide",
      "Certificate of completion"
    ]
  },
  {
    id: 2,
    title: "Coffee Cupping: Single Origin Showcase",
    description: "Join us for an evening of coffee tasting featuring rare single-origin beans from Ethiopia, Panama, and Yemen.",
    date: "2025-03-01",
    time: "18:00-20:00",
    location: {
      name: "Sightglass Coffee",
      address: "270 7th St, San Francisco, CA 94103",
      shopId: 2
    },
    type: "tasting",
    price: 45,
    capacity: 20,
    registrationUrl: "https://example.com/events/cupping-2025",
    imageUrl: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800",
    tags: ["tasting", "educational", "social"],
    included: [
      "Guided tasting of 6 coffees",
      "Tasting journal",
      "Light snacks",
      "10% discount on featured beans"
    ]
  },
  {
    id: 3,
    title: "SF Coffee Innovation Summit",
    description: "A day-long conference exploring the future of coffee, featuring talks on sustainability, technology, and craft.",
    date: "2025-04-20",
    time: "09:00-17:00",
    location: {
      name: "SF Coffee Innovation Center",
      address: "123 Market St, San Francisco, CA 94105"
    },
    type: "meetup",
    price: 150,
    capacity: 200,
    registrationUrl: "https://example.com/events/summit-2025",
    imageUrl: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=800",
    speakers: [
      {
        name: "Dr. James Wong",
        role: "Coffee Research Director",
        company: "Global Coffee Institute",
        bio: "Leading researcher in sustainable coffee farming",
        imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400"
      },
      {
        name: "Sarah Martinez",
        role: "CEO",
        company: "TechBrew Solutions",
        bio: "Pioneer in AI-driven coffee roasting technology",
        imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400"
      }
    ],
    tags: ["conference", "networking", "innovation"],
    included: [
      "Full day of presentations",
      "Networking lunch",
      "Coffee tasting sessions",
      "Digital conference materials"
    ]
  }
];