import type { HiddenGem } from '../types/guides';

export const hiddenGems: HiddenGem[] = [
  {
    id: 1,
    shopId: 8, // Flywheel Coffee
    whyHidden: 'Tucked away in a historic building with minimal signage, this Vietnamese-owned roastery combines traditional techniques with modern craft coffee.',
    bestTimeToVisit: 'Early weekday mornings or late Sunday afternoons',
    uniqueFeatures: [
      'Traditional Vietnamese coffee preparation',
      'Rare single-origin beans',
      'Historic architecture and original fixtures',
      'Secret garden seating area'
    ],
    localStories: [
      'Started by a family that has been in coffee for three generations',
      'Building was once a famous jazz club in the 1950s',
      'Their signature roast was developed over 20 years'
    ]
  },
  {
    id: 2,
    shopId: 9, // Coffee Movement
    whyHidden: 'Despite its central location, this educational-focused coffee bar is easy to miss, housed in a converted Victorian home.',
    bestTimeToVisit: 'Mid-morning on weekdays or Sunday afternoons',
    uniqueFeatures: [
      'Coffee flight tastings',
      'Rotating international brewing methods',
      'Underground cupping room',
      'Experimental coffee cocktails'
    ],
    localStories: [
      'Founded by former coffee competition judges',
      'Hosts underground coffee workshops',
      'Features a different local artist monthly'
    ]
  }
];