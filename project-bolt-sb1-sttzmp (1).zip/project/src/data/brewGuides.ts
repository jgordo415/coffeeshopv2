import type { BrewGuide } from '../types/brewGuides';

export const brewGuides: BrewGuide[] = [
  {
    id: 1,
    method: "Pour Over",
    difficulty: "Intermediate",
    timeRequired: "5-7 minutes",
    grindSize: "Medium-fine",
    waterTemp: "200°F (93°C)",
    yield: "12 oz (350ml)",
    ratio: {
      coffee: "22g",
      water: "350g",
    },
    steps: [
      "Heat water to 200°F",
      "Rinse filter with hot water",
      "Add 22g of medium-fine ground coffee",
      "Pour 50g of water for blooming (30 seconds)",
      "Gradually pour remaining water in circular motion",
      "Total brew time should be 3-4 minutes"
    ],
    equipment: [
      "V60 or Chemex",
      "Paper filter",
      "Gooseneck kettle",
      "Scale",
      "Timer",
      "Burr grinder"
    ],
    tips: [
      "Use filtered water for better taste",
      "Maintain consistent water temperature",
      "Time your pour intervals",
      "Ensure even bed of grounds"
    ]
  },
  {
    id: 2,
    method: "French Press",
    difficulty: "Beginner",
    timeRequired: "8-10 minutes",
    grindSize: "Coarse",
    waterTemp: "200°F (93°C)",
    yield: "16 oz (475ml)",
    ratio: {
      coffee: "30g",
      water: "475g",
    },
    steps: [
      "Heat water to 200°F",
      "Coarsely grind 30g of coffee",
      "Add coffee to French press",
      "Pour hot water over grounds",
      "Stir gently",
      "Place plunger on top without pressing",
      "Steep for 4 minutes",
      "Press plunger down slowly",
      "Serve immediately"
    ],
    equipment: [
      "French press",
      "Kettle",
      "Scale",
      "Timer",
      "Burr grinder",
      "Stirring spoon"
    ],
    tips: [
      "Use coarse grounds to prevent over-extraction",
      "Don't press too hard when plunging",
      "Decant coffee immediately to prevent over-extraction",
      "Pre-heat the French press with hot water"
    ]
  },
  {
    id: 3,
    method: "Cappuccino",
    difficulty: "Advanced",
    timeRequired: "5-7 minutes",
    grindSize: "Fine (espresso)",
    waterTemp: "200°F (93°C)",
    yield: "6 oz (180ml)",
    ratio: {
      coffee: "18g",
      water: "36g (shot)",
    },
    steps: [
      "Grind 18g coffee for espresso",
      "Tamp grounds evenly with 30 lbs pressure",
      "Pull a double shot (25-30 seconds)",
      "Steam milk to 150°F (65°C)",
      "Create microfoam while steaming",
      "Swirl milk to maintain texture",
      "Pour milk over espresso at 45° angle",
      "Create latte art (optional)"
    ],
    equipment: [
      "Espresso machine",
      "Burr grinder",
      "Milk pitcher",
      "Thermometer",
      "Scale",
      "Tamper",
      "Milk steaming pitcher"
    ],
    tips: [
      "Use fresh whole milk for best foam",
      "Keep milk pitcher in refrigerator",
      "Listen for 'paper tearing' sound while steaming",
      "Tap pitcher to remove large bubbles",
      "Clean steam wand immediately after use"
    ]
  }
];

export const espressoDrinks: DrinkComparison[] = [
  {
    name: "Espresso",
    description: "Pure concentrated coffee extracted under pressure",
    ratio: {
      espresso: "100%",
      milk: "0%",
      foam: "0%"
    },
    size: "1 oz (30ml)",
    characteristics: [
      "Intense flavor",
      "Rich crema",
      "No milk"
    ],
    imageUrl: "/images/drinks/espresso.svg"
  },
  {
    name: "Macchiato",
    description: "Espresso 'marked' with a small amount of steamed milk",
    ratio: {
      espresso: "90%",
      milk: "10%",
      foam: "Dot"
    },
    size: "1.5 oz (45ml)",
    characteristics: [
      "Mostly espresso",
      "Tiny bit of milk",
      "Small dot of foam"
    ],
    imageUrl: "/images/drinks/macchiato.svg"
  },
  {
    name: "Cortado",
    description: "Equal parts espresso and steamed milk",
    ratio: {
      espresso: "50%",
      milk: "50%",
      foam: "Minimal"
    },
    size: "4 oz (120ml)",
    characteristics: [
      "Balanced ratio",
      "Smooth texture",
      "Light foam"
    ],
    imageUrl: "/images/drinks/cortado.svg"
  },
  {
    name: "Flat White",
    description: "Double shot of espresso with velvety steamed milk",
    ratio: {
      espresso: "33%",
      milk: "67%",
      foam: "Minimal"
    },
    size: "6 oz (180ml)",
    characteristics: [
      "Strong coffee taste",
      "Creamy microfoam",
      "No distinct foam layer"
    ],
    imageUrl: "/images/drinks/flat-white.svg"
  },
  {
    name: "Cappuccino",
    description: "Equal parts espresso, steamed milk, and milk foam",
    ratio: {
      espresso: "33%",
      milk: "33%",
      foam: "33%"
    },
    size: "6 oz (180ml)",
    characteristics: [
      "Three distinct layers",
      "Thick foam cap",
      "Traditional size"
    ],
    imageUrl: "/images/drinks/cappuccino.svg"
  },
  {
    name: "Latte",
    description: "Espresso with steamed milk and small layer of foam",
    ratio: {
      espresso: "25%",
      milk: "65%",
      foam: "10%"
    },
    size: "8-12 oz (240-360ml)",
    characteristics: [
      "Mild coffee taste",
      "Creamy texture",
      "Light foam top"
    ],
    imageUrl: "/images/drinks/latte.svg"
  }
];