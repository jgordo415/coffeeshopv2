import type { LandmarkGuide } from '../types/guides';

export const landmarkGuides: LandmarkGuide[] = [
  {
    id: 'golden-gate-park',
    name: 'Golden Gate Park',
    description: 'Find the perfect coffee spot before or after exploring San Francisco\'s largest park.',
    imageUrl: 'https://images.unsplash.com/photo-1549751299-5ca0abc31554',
    coffeeShops: [
      {
        id: 8, // Flywheel Coffee Roasters
        distance: '0.2 miles',
        walkingTime: '4 minutes',
        highlights: [
          'Right across from the park',
          'Spacious outdoor seating',
          'Perfect pre-park fuel stop'
        ]
      },
      {
        id: 4, // Andytown
        distance: '0.5 miles',
        walkingTime: '10 minutes',
        highlights: [
          'Famous Snowy Plover drink',
          'Fresh pastries daily',
          'Quick service for park-goers'
        ]
      }
    ]
  },
  {
    id: 'fishermans-wharf',
    name: 'Fisherman\'s Wharf',
    description: 'Escape the tourist traps and find authentic coffee experiences near the waterfront.',
    imageUrl: 'https://images.unsplash.com/photo-1564349683136-77e08dba1ef7',
    coffeeShops: [
      {
        id: 5, // Equator Coffees
        distance: '0.8 miles',
        walkingTime: '15 minutes',
        highlights: [
          'Waterfront views',
          'Sustainable practices',
          'Local favorite amid tourist spots'
        ]
      }
    ]
  }
];